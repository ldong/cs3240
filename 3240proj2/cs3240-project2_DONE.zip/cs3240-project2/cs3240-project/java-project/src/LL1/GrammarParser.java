package LL1;

import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

/**
 * Grammar Parser which parses the grammar into Rules
 */
public class GrammarParser {
  public static String startRule = "";

  /* Create a list which holds the grammar rules */
  public static List<ProductionRule>
      ParseGrammer(Scanner scan) {
    List<ProductionRule> allProductionRuleAccumulated = new LinkedList<ProductionRule>();
    while (scan.hasNextLine()) {
      String currentLine = scan.nextLine();
      if (currentLine.trim().equals("")) {
        continue;
      }
      String[] lhsAndRhs = currentLine.split("::=");
      //  System.out.println(Arrays.toString(lhsAndRhs));
      if (lhsAndRhs.length != 2) {
        System.err.println("Line is malformed: " + currentLine);
        System.exit(1);
      }
      String leftHand = lhsAndRhs[0];
      String[] possibleTransitions = lhsAndRhs[1].split("\\|");
      for (String transition : possibleTransitions) {
        transition = transition.trim();
        if (transition.equals("")) {
          continue;
        }
        String[] allElements = transition.split(" ");
        ProductionRule currentRule = new ProductionRule(leftHand);
        for (String element : allElements) {
          element = element.trim();
          if (element.equals("")) {
            continue;
          }
          Token currentToken = null;
          if (TokenClass.isValidTokenClass(element)) {
            currentToken = TokenClass.getToken(element, "");
          } else if (element.startsWith("<") && element.endsWith(">")
              && !element.equalsIgnoreCase("<epsilon>")) {
            currentToken = NonTerminal.getNonTerminalFor(element);
          } else {
            currentToken = Terminal.getTerminalOf(element);
          }
          currentRule.appendToken(currentToken);
        }
        allProductionRuleAccumulated.add(currentRule);
      }
      if (startRule.equals("")) {
        startRule = leftHand;
      }
    }
    return allProductionRuleAccumulated;
  }
}
