package LL1;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

/**
 * A class that holds all Non-Terminals
 *
 */
public class NonTerminal extends Token {
  private String ruleName;
  private static Map<String, NonTerminal> cache = new HashMap<String, NonTerminal>();

  public NonTerminal(String lhs) {
    ruleName = lhs;
  }

  public static Collection<NonTerminal> getAllNonTerminals() {
    return cache.values();
  }

  /**
   * Get the non-terminal tokens
   * @param lhs
   * @return
   */
  public static NonTerminal getNonTerminalFor(String lhs) {
    lhs = lhs.trim();
    NonTerminal returnValue = cache.get(lhs);
    if (returnValue == null) {
      returnValue = new NonTerminal(lhs);
      cache.put(lhs, returnValue);
    }
    return returnValue;
  }

  @Override
  public boolean matches(Token t) {
    return false;
  }

  @Override
  public String getTokenClass() {
    return ruleName;
  }

  @Override
  public String getTokenValue() {
    return null;
  }

  @Override
  public boolean isTerminal() {
    return false;
  }

  public String toString() {
    return ruleName;
  }

  public int hashCode() {
    return ruleName.hashCode();
  }

  public boolean equals(Object o) {
    if (!(o instanceof NonTerminal)) {
      return false;
    }
    return ruleName.equals(((NonTerminal) o).ruleName);
  }
}
