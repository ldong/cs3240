package LL1;

import java.util.LinkedList;
import java.util.List;

/**
 * A class which holds the Production Rules 
 * In term of left-hand-side and right-hand-side
 */
public class ProductionRule {
  private NonTerminal leftHandSide;
  private List<Token> rightHandSide;

  public ProductionRule(String lhs) {
    leftHandSide = NonTerminal.getNonTerminalFor(lhs);
    rightHandSide = new LinkedList<Token>();
  }

  public void appendToken(Token t) {
    rightHandSide.add(t);
  }

  public String toString() {
    return leftHandSide.toString() + "->" + rightHandSide.toString();
  }

  public int hashCode() {
    return leftHandSide.hashCode() * rightHandSide.hashCode();
  }

  public NonTerminal getLHS() {
    return leftHandSide;
  }

  public List<Token> getRHS() {
    return rightHandSide;
  }
}
