package LL1;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

/**
 * A class which holds all the Tokens
 */
public class Terminal extends Token {
  private String internallyAssignedType;
  private String value;
  private static Map<String, Terminal> cache = new HashMap<String, Terminal>();
  public static final String unmatchedClassString = "Unmatched Class! :/";

  /**
   * Constructor for terminal
   * @param tokenClass
   * @param matchedValue
   */
  public Terminal(String tokenClass, String matchedValue) {
    internallyAssignedType = tokenClass;
    value = matchedValue;
  }

  /**
   * Return all the terminals
   * @return
   */
  public static Collection<Terminal> getAllTerminals() {
    return cache.values();
  }

  /**
   * Get the terminals from specific string 
   * @param terminal
   * @return
   */
  public static Terminal getTerminalOf(String terminal) {
    terminal = terminal.trim();
    Terminal returnValue = cache.get(terminal);
    if (returnValue == null) {
      returnValue = new Terminal(unmatchedClassString, terminal);
      cache.put(terminal, returnValue);
    }
    return returnValue;
  }

  /**
   * Return whether the terminal already exists
   * @param terminal
   * @return
   */
  public static boolean isExpectedTerminal(String terminal) {
    return cache.containsKey(terminal);
  }

  @Override
  public boolean matches(Token t) {
    if (t.isTerminal()) {
      return t.getTokenClass().equals(getTokenClass());
    }
    return false;
  }

  @Override
  public String getTokenClass() {
    return internallyAssignedType;
  }

  @Override
  public String getTokenValue() {
    return value;
  }

  @Override
  public boolean isTerminal() {
    return true;
  }

  public void setTokenClass(String t) {
    internallyAssignedType = t;
  }

  public String toString() {
    return "(" + internallyAssignedType + ", " + value + ")";
  }

  public int hashCode() {
    if (internallyAssignedType.equals(unmatchedClassString)) {
      return value.hashCode();
    }
    return internallyAssignedType.hashCode();
  }

  public boolean equals(Object o) {
    if (o == null || !(o instanceof Token)) {
      return false;
    }
    if (internallyAssignedType.equals(unmatchedClassString)) {
//      System.out.println("His: " + ((Token) o).getTokenValue());
//      System.out.println("Mine: " + value);
      return ((Token) o).getTokenValue().equals(value);
    }
    return ((Token) o).getTokenClass().equals(internallyAssignedType);
  }
}
