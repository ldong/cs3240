package LL1;

/**
 * Token Interface Class
 */
public abstract class Token {
  /**
   * @param t token type
   * @return
   */
  public abstract boolean matches(Token t);

  public abstract String getTokenClass();

  public abstract String getTokenValue();
  
  public abstract boolean isTerminal();
  

}
