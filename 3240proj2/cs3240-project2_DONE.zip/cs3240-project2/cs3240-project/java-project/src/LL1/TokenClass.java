package LL1;

import java.util.HashSet;
import java.util.Set;

/**
 * Class which identifies which string belongs to which token type
 * @author ldong
 *
 */
public class TokenClass extends Token {
  private String tokenClass;
  private String tokenMatched;
  public static Set<String> tokenClasses = new HashSet<String>();

  private TokenClass(String tokenClass, String actualToken) {
    this.tokenClass = tokenClass;
    this.tokenMatched = actualToken;
  }

  /**
   * Generate/ Identify the token types based on inputs
   * @param aTokenClass
   * @param value
   * @return
   */
  public static Token getToken(String aTokenClass, String value) {
    aTokenClass = aTokenClass.trim();
    value = value.trim();
    if (!isValidTokenClass(aTokenClass)) {
      System.err
          .println("I was trying to initialize a token class when it wasn't even a valid token class");
      System.err.println(aTokenClass);
      return null;
    }
    tokenClasses.add(aTokenClass);
    return new TokenClass(aTokenClass, value);
  }

  @Override
  public boolean matches(Token t) {
    if (!t.isTerminal()) {
      return false;
    }
    return t.getTokenClass().equals(getTokenClass());
  }

  public static void addTokenClass(String tc) {
    tokenClasses.add(tc);
  }

  public static boolean isValidTokenClass(
      String anyString) {
    return tokenClasses.contains(anyString);
  }

  @Override
  public String getTokenClass() {
    return tokenClass;
  }

  @Override
  public String getTokenValue() {
    return tokenMatched;
  }

  @Override
  public boolean isTerminal() {
    return true;
  }

  public String toString() {
    return "(" + tokenClass + ", " + tokenMatched + ")";
  }

  public boolean equals(Object o) {
    if (o == null || !(o instanceof Token)) {
      return false;
    }
    if (o == this) {
      return true;
    }
    return getTokenClass().equals(((Token) o).getTokenClass());
  }

  public int hashCode() {
    
    return tokenClass.hashCode();
  }
}
