package LL1;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

/**
 * Convert the given inputs in term of string into expected token types
 *
 */
public class TokenConvertor {
  public static List<Token> getTokensFromFile(String fileName) {
    LinkedList<Token> returnValue = new LinkedList<Token>();
    try {
      Scanner scan = new Scanner(new File(fileName));
      while (scan.hasNextLine()) {
        String[] tokens = scan.nextLine().split(" ");
        String tokenType = tokens[0];
        String tokenMatch = tokens[1];
        Token currentToken = null;
        if (Terminal.isExpectedTerminal(tokenMatch)) {
          currentToken = Terminal.getTerminalOf(tokenMatch);
        } else {
          currentToken = TokenClass.getToken(tokenType, tokenMatch);
        }
        returnValue.addLast(currentToken);
      }
      scan.close();
    } catch (FileNotFoundException e) {
      e.printStackTrace();
    }
    returnValue.addLast(Terminal.getTerminalOf("<end-of-file>"));
    return returnValue;
  }
}
