package LL1;

import java.io.PrintStream;
import java.util.List;
import java.util.Stack;

/**
 * Table Walker for LL1 Parsing Table
 * that will walk through the table
 */
public class LL1TableWalker {
  public static void
      printTokens(LL1ParsingTable table, List<Token> input, PrintStream p) {
    Stack<Token> theStack = new Stack<Token>();
    Token theDestination = Terminal.getTerminalOf("<end-of-file>");
    theStack
        .push(theDestination);
    theStack.push(NonTerminal.getNonTerminalFor(GrammarParser.startRule));
    
    /*
     * While not done
     */
    while (!theStack.peek().equals(theDestination)) {
      p.println(theStack);
      if (theStack.peek().isTerminal()) {
        if (theStack.peek().matches(input.get(0))) {
          p.println("Matched: " + theStack.peek() + " with " + input.get(0));
          input.remove(0);
          theStack.pop();
        } else {
          System.err.println("Didn't match :" + theStack.peek() + " with: "
              + input.get(0));
          System.exit(1);
        }
      } else if (!theStack.peek().isTerminal()) {
        NonTerminal state = (NonTerminal) theStack.pop();
        ProductionRule next = table.index(state, input.get(0));
        if (next == null) {
          System.err.println("Can't go any where from: " + state);
          System.err.println("Stack: " + theStack);
          System.err.println("Token: " + input.get(0));
          System.exit(1);
        }
        p.println("Poping off: " + state);
        p.println("Following: " + next);
        List<Token> tokensToPush = next.getRHS();
        if (tokensToPush.size() == 1
            && tokensToPush.get(0).matches(Terminal.getTerminalOf("<epsilon>"))) {
          continue;
        }
        for (int i = tokensToPush.size() - 1; i >= 0; i--) {
          theStack.push(tokensToPush.get(i));
        }
      }
      p.println();
    }
    if (theStack.peek().matches(input.get(0))) {
      p.println("The string is valid.");
    } else {
      p.println("The string is invalid.");
    }
  }
}
