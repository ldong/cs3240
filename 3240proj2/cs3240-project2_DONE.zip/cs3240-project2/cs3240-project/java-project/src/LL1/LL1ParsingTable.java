package LL1;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class LL1ParsingTable {
  private Map<NonTerminal, Integer> nonterminalToIndex;
  private Map<Token, Integer> terminalToIndex;
  private Map<Token, Set<Token>> firstSets;
  private Map<NonTerminal, Set<Token>> followSets;
  private ProductionRule[][] table;
  private Map<NonTerminal, List<ProductionRule>> allRules;

  /**
   * Constructor for LL1 Parsing Table
   * @param rules
   *        Production Rule
   */
  public LL1ParsingTable(List<ProductionRule> rules) {
    allRules = new HashMap<NonTerminal, List<ProductionRule>>();
    firstSets = new HashMap<Token, Set<Token>>();
    nonterminalToIndex = new HashMap<NonTerminal, Integer>();
    terminalToIndex = new HashMap<Token, Integer>();
    followSets = new HashMap<NonTerminal, Set<Token>>();
    for (int i = 0; i < rules.size(); i++) {
      ProductionRule p = rules.get(i);
      if (!allRules.containsKey(p.getLHS())) {
        allRules.put(p.getLHS(), new LinkedList<ProductionRule>());
      }
      allRules.get(p.getLHS()).add(p);
    }
    table = new ProductionRule[NonTerminal.getAllNonTerminals().size()][Terminal
        .getAllTerminals().size()
        + TokenClass.tokenClasses.size() + 1];
    updateNonTerminalIndices();
    updateTokenIndices();
    updateFirstSets();
    updateFollowSets();
    updateTableFromFollowSets();
    //System.out.println(followSets);
  }

  /**
   * Update the table from the follow sets
   */
  private void updateTableFromFollowSets() {
    Iterator<NonTerminal> allNonTerminals = NonTerminal
        .getAllNonTerminals().iterator();
    while (allNonTerminals.hasNext()) {
      NonTerminal nt = allNonTerminals.next();
      if (!firstSets.get(nt).contains(Terminal.getTerminalOf("<epsilon>"))) {
        continue;
      }
      ProductionRule pr = new ProductionRule(nt.getTokenClass());
      pr.appendToken(Terminal.getTerminalOf("<epsilon>"));
      Set<Token> currentFollowSet = followSets.get(nt);
      Iterator<Token> allFollowables = currentFollowSet.iterator();
      while (allFollowables.hasNext()) {
        Token ts = allFollowables.next();
        ProductionRule old = table[nonterminalToIndex.get(nt)][terminalToIndex
            .get(ts)];
        if (old == null & old != pr) {
          table[nonterminalToIndex.get(nt)][terminalToIndex
              .get(ts)] = pr;
        } else {
          System.err.println("LL1ParsingTable.updateTableFromFollowSets()");
          System.err.println("This is not a LL(1) grammar. ");
          System.err.println("Found : " + old);
          System.err.println("Class of " + ts.getClass());
          System.err.println("At: " + nt + " T: " + ts);
          System.exit(0);
        }
      }
    }
  }

  /**
   * Update the Follow Sets
   */
  private void updateFollowSets() {
    // System.out.println("LL1ParsingTable.updateFollowSets()");
    //int iterationNumber = 0;
    Iterator<NonTerminal> allNonTerminals = NonTerminal
        .getAllNonTerminals()
        .iterator();
    while (allNonTerminals.hasNext()) {
      NonTerminal n = allNonTerminals.next();
      followSets.put(n, new HashSet<Token>());
    }
    Terminal endOfFileSymbol = Terminal.getTerminalOf("<end-of-file>");
    followSets.get(NonTerminal.getNonTerminalFor(GrammarParser.startRule))
        .add(endOfFileSymbol);
    boolean wasThereAnyChange = true;
    while (wasThereAnyChange) {
      //System.out.println(iterationNumber++);
      wasThereAnyChange = false;
      allNonTerminals = NonTerminal.getAllNonTerminals().iterator();
      while (allNonTerminals.hasNext()) {
        NonTerminal A = allNonTerminals.next();
        if (A.getTokenClass().equals(GrammarParser.startRule)) {
          continue;
        }
        List<ProductionRule> allProductionChoices = allRules.get(A);
        for (ProductionRule aProductionChoice : allProductionChoices) {
          if (aProductionChoice == null) {
            continue;
          }
          List<Token> allSymbols = aProductionChoice.getRHS();
          for (int i = 0; i < allSymbols.size(); i++) {
            Token t = allSymbols.get(i);
            if (t.isTerminal()) {
              continue;
            }
            NonTerminal Xi = (NonTerminal) t;
            Set<Token> currentFollowSet = followSets.get(Xi);
            int k = i + 1;
            boolean toContinue = true;
            while (k < allSymbols.size() && toContinue) {
              toContinue = false;
              Token currentToken = allSymbols.get(k++);
              currentFollowSet
                  .addAll(firstSets.get(currentToken));
              if (!currentToken.isTerminal()
                  && firstSets
                      .get(currentToken)
                      .contains(
                          Terminal.getTerminalOf("<epsilon>"))) {
                toContinue = true;
              }
            }
            if (toContinue) {
              if (currentFollowSet
                  .addAll(followSets.get(A))) {
                wasThereAnyChange = true;
              }
            }
            currentFollowSet.remove(Terminal
                .getTerminalOf("<epsilon>"));
            if (followSets.get(Xi).addAll(currentFollowSet)) {
              wasThereAnyChange = true;
            }
          }
        }
      }
    }
  }

  /**
   * update the First Sets
   */
  private void updateFirstSets() {
    // System.out.println("LL1ParsingTable.updateFirstSets()");
    Iterator<NonTerminal> allNonTerminals = NonTerminal
        .getAllNonTerminals()
        .iterator();
    while (allNonTerminals.hasNext()) {
      firstSets.put(allNonTerminals.next(), new HashSet<Token>());
    }
    Iterator<String> allTokenClasses = TokenClass.tokenClasses.iterator();
    while (allTokenClasses.hasNext()) {
      String curr = allTokenClasses.next();
      Set<Token> s = new HashSet<Token>();
      s.add(TokenClass.getToken(curr, ""));
      firstSets.put(TokenClass.getToken(curr, ""), s);
    }
    Iterator<Terminal> allTerminals = Terminal.getAllTerminals().iterator();
    while (allTerminals.hasNext()) {
      Terminal t = allTerminals.next();
      Set<Token> s = new HashSet<Token>();
      s.add(t);
      firstSets.put(t, s);
    }
    boolean wereThereAnyChanges;
    do {
      wereThereAnyChanges = false;
      Iterator<Entry<NonTerminal, List<ProductionRule>>> it = allRules
          .entrySet().iterator();
      while (it.hasNext()) {
        Entry<NonTerminal, List<ProductionRule>> current = it.next();
        //   NonTerminal A = current.getKey();
        //  System.out.println("Processing Non terminal :" + A);
        List<ProductionRule> currentRules = current.getValue();
        for (ProductionRule productionChoice : currentRules) {
          if (productionChoice == null) {
            continue;
          }
          //  System.out.println("Processing production choice: "
          //    + productionChoice);
          int k = 0;
          boolean toContinue = true;
          List<Token> symbols = productionChoice.getRHS();
          Set<Token> newAdditions = new HashSet<Token>();
          while (k < symbols.size() && toContinue) {
            newAdditions.addAll(
                firstSets.get(symbols.get(k)));
            if (firstSets.get(symbols.get(k)) == null) {
              System.err
                  .println("First set of " + symbols.get(k)
                      + " was null");
              System.exit(1);
            }
            if (firstSets.get(symbols.get(k)).contains(
                Terminal.getTerminalOf("<epsilon>")) == false) {
              toContinue = false;
            }
            k++;
          }
          if (toContinue) {
            newAdditions.add(Terminal.getTerminalOf("<epsilon>"));
          } else {
            newAdditions
                .remove(Terminal.getTerminalOf("<epsilon>"));
          }
          for (Iterator<Token> alpha = newAdditions.iterator(); alpha
              .hasNext();) {
            int nonTerminalIndex = nonterminalToIndex
                .get(productionChoice
                    .getLHS());
            Token currentToken = alpha.next();
//            String dbg = currentToken
//                .getTokenValue();
//            System.out.println(dbg);
            int terminalIndex = terminalToIndex.get(currentToken);
            ProductionRule old = table[nonTerminalIndex][terminalIndex];
            if (old != productionChoice && old != null) {
              System.err.println("LL1ParsingTable.updateFirstSets()");
              System.err.println(terminalToIndex);
              System.err.println("This is not a LL(1) grammar");
              System.err.println("For rule: " + productionChoice);
              System.err.println("We saw " + old + " at: ");
              System.err.println("table["
                  + productionChoice.getLHS() + "]["
                  + currentToken + "]");
              System.exit(0);
            }
            table[nonTerminalIndex][terminalIndex] = productionChoice;
          }
          if (firstSets.get(productionChoice.getLHS()).addAll(
              newAdditions)) {
            wereThereAnyChanges = true;
          }
        }
      }
    }
    while (wereThereAnyChanges);
  }

  /**
   * Update the Non-Terminal Index
   */
  private void updateNonTerminalIndices() {
    Iterator<NonTerminal> nonTerminals = NonTerminal.getAllNonTerminals()
        .iterator();
    int index = 0;
    while (nonTerminals.hasNext()) {
      nonterminalToIndex.put(nonTerminals.next(), index++);
    }
  }

  /**
   * Update the current Token's Index
   */
  private void updateTokenIndices() {
    Iterator<Terminal> terminals = Terminal.getAllTerminals()
        .iterator();
    Iterator<String> toks = TokenClass.tokenClasses.iterator();
    int index = 0;
    while (terminals.hasNext()) {
      terminalToIndex.put(terminals.next(), index++);
    }
    while (toks.hasNext()) {
      terminalToIndex.put(TokenClass.getToken(toks.next(), ""), index++);
    }
    terminalToIndex.put(Terminal.getTerminalOf("<end-of-file>"), index++);
  }

  /**
   * Return the part of the table the parser is dealing with currently
   * @param state
   * @param next
   * @return
   */
  public ProductionRule index(NonTerminal state, Token next) {
    int l = nonterminalToIndex.get(state);
    int r = terminalToIndex.get(next);
    return table[l][r];
  }
}
