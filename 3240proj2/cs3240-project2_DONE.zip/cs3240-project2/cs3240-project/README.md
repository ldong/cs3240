This is GLib
http://developer.gnome.org/glib/stable/

Using git rev-list --remotes
<br/>
Using git checkout master~X, x is the number of revision
<br/>
